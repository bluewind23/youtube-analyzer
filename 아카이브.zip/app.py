# 복사 버튼을 눌러 전체 코드를 복사하세요
from routes.user_actions_routes import user_actions_routes
from routes.admin_routes import admin_routes
from routes.channel_routes import channel_routes
from routes.auth_routes import auth_routes, google_bp
from routes.main_routes import main_routes

from flask import Flask, render_template, redirect, request, session
from flask_migrate import Migrate
from config import Config
from extensions import db, cache
from models.user import User
from flask_login import LoginManager
from jinja2.runtime import Undefined
import os
# [수정 또는 추가할 코드 시작]
# ProxyFix 임포트
from werkzeug.middleware.proxy_fix import ProxyFix
# 환경변수 로드 (개발환경용, 프로덕션에서는 시스템 환경변수 사용)
from dotenv import load_dotenv
load_dotenv()  # .env 파일이 없어도 에러가 발생하지 않음
# [수정 또는 추가할 코드 끝]

app = Flask(__name__)

# [수정 또는 추가할 코드 시작]
# WSGI 미들웨어에 ProxyFix 적용. 반드시 app = Flask(__name__) 바로 다음에 위치해야 합니다.
# 이 코드는 서버가 프록시(예: Render) 뒤에 있을 때 올바른 URL(https, 도메인 등)을 인식하게 해줍니다.
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)
# [수정 또는 추가할 코드 끝]

app.secret_key = os.environ.get("FLASK_SECRET_KEY", "your-secret-key")
# 세션 설정 추가 (HTTPS 환경 대응)
app.config['SESSION_COOKIE_SECURE'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'None'

# 숫자를 사람이 읽기 쉬운 형태로 변환하는 필터


def human_format(num):
    if num is None or isinstance(num, Undefined):
        return ""
    num = float('{:.3g}'.format(num))
    magnitude = 0
    while abs(num) >= 10000 and magnitude < 3:
        magnitude += 1
        num /= 10000.0
    unit = ['', '만', '억', '조'][magnitude]
    if num % 1 == 0:
        return '{}{}'.format(int(num), unit)
    return '{:.1f}{}'.format(num, unit).replace('.0', '')


app.jinja_env.filters['human_format'] = human_format
app.jinja_env.add_extension('jinja2.ext.do')

# Config 적용 및 캐시 설정
app.config.from_object(Config)
app.config['CACHE_TYPE'] = 'SimpleCache'
app.config['CACHE_DEFAULT_TIMEOUT'] = 300

# 확장 기능 초기화
cache.init_app(app)
db.init_app(app)
migrate = Migrate(app, db, render_as_batch=True)

# 로그인 매니저 설정
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth_routes.login'
login_manager.login_message = '이 페이지에 접근하려면 로그인이 필요합니다.'
login_manager.login_message_category = 'info'


@login_manager.user_loader
def load_user(user_id):
    print(f"[DEBUG] load_user called with user_id: {user_id}")
    try:
        user = User.query.get(int(user_id))
        print(f"[DEBUG] User found: {user}")
        return user
    except Exception as e:
        print(f"[DEBUG] Error in load_user: {e}")
        return None


# 블루프린트 등록
app.register_blueprint(main_routes)
app.register_blueprint(auth_routes)
app.register_blueprint(google_bp, url_prefix="/login")
app.register_blueprint(channel_routes)
app.register_blueprint(admin_routes)
app.register_blueprint(user_actions_routes)

# 에러 핸들러


@app.errorhandler(404)
def not_found_error(error):
    return render_template('errors/404.html'), 404


@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('errors/500.html'), 500


@app.errorhandler(503)
def service_unavailable(error):
    return render_template('errors/503.html'), 503


@app.route('/debug/session')
def debug_session():
    return {
        'session_data': dict(session),
        'session_keys': list(session.keys()),
        'user_in_session': 'user' in session,
        'google_token': 'google_token' in session if 'google_token' in session else 'No google_token',
        'session_id': request.cookies.get('session', 'No session cookie')
    }


@app.route('/debug/routes')
def debug_routes():
    import urllib
    output = []
    for rule in app.url_map.iter_rules():
        methods = ','.join(rule.methods)
        line = urllib.parse.unquote(
            f"{rule.endpoint:50s} {methods:20s} {rule}")
        output.append(line)

    # 환경변수도 함께 확인
    env_vars = {
        'ADMIN_SECRET_PATH': os.environ.get('ADMIN_SECRET_PATH', 'NOT_SET'),
        'ADMIN_EMAIL': os.environ.get('ADMIN_EMAIL', 'NOT_SET')
    }

    return {
        'routes': sorted(output),
        'environment_variables': env_vars,
        'total_routes': len(output)
    }


# 앱 실행
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=False)
