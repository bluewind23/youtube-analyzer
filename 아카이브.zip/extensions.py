from flask_caching import Cache
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import MetaData

cache = Cache()

# 데이터베이스 제약조건에 대한 이름 규칙 정의
convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s"
}

metadata = MetaData(naming_convention=convention)

db = SQLAlchemy(metadata=metadata)